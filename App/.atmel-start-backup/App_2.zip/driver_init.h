/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#ifndef DRIVER_INIT_H_INCLUDED
#define DRIVER_INIT_H_INCLUDED

#include "atmel_start_pins.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <hal_atomic.h>
#include <hal_delay.h>
#include <hal_gpio.h>
#include <hal_init.h>
#include <hal_io.h>
#include <hal_sleep.h>

#include <hal_pwm.h>
#include <hal_crc_sync.h>

#include <hal_usart_os.h>

#include <hal_usart_os.h>

#include <hal_usart_os.h>

#define USART_BLE_BUFFER_SIZE 16

#define USART_STN_BUFFER_SIZE 16

#define USART_DEBUG_BUFFER_SIZE 16

extern struct pwm_descriptor      PWM_0;
extern struct crc_sync_descriptor CRC_0;

extern struct usart_os_descriptor USART_BLE;
extern uint8_t                    USART_BLE_buffer[];

extern struct usart_os_descriptor USART_STN;
extern uint8_t                    USART_STN_buffer[];

extern struct usart_os_descriptor USART_DEBUG;
extern uint8_t                    USART_DEBUG_buffer[];

void USART_BLE_PORT_init(void);
void USART_BLE_CLOCK_init(void);
void USART_BLE_init(void);

void USART_STN_PORT_init(void);
void USART_STN_CLOCK_init(void);
void USART_STN_init(void);

void USART_DEBUG_PORT_init(void);
void USART_DEBUG_CLOCK_init(void);
void USART_DEBUG_init(void);

/**
 * \brief Perform system initialization, initialize pins and clocks for
 * peripherals
 */
void system_init(void);

#ifdef __cplusplus
}
#endif
#endif // DRIVER_INIT_H_INCLUDED
