/**
 * \file
 *
 * \brief SAM Serial Communication Interface
 *
 * Copyright (C) 2016 - 2017 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */
#include <hpl_usart_async.h>
#include <hpl_usart_config.h>
#include <hpl_usart_sync.h>
#include <peripheral_clk_config.h>
#include <utils.h>
#include <utils_assert.h>

#ifndef CONF_USART_0_ENABLE
#define CONF_USART_0_ENABLE 0
#endif
#ifndef CONF_USART_1_ENABLE
#define CONF_USART_1_ENABLE 0
#endif
#ifndef CONF_USART_2_ENABLE
#define CONF_USART_2_ENABLE 0
#endif
#ifndef CONF_USART_3_ENABLE
#define CONF_USART_3_ENABLE 0
#endif
#ifndef CONF_USART_4_ENABLE
#define CONF_USART_4_ENABLE 0
#endif
#ifndef CONF_USART_5_ENABLE
#define CONF_USART_5_ENABLE 0
#endif
#ifndef CONF_USART_6_ENABLE
#define CONF_USART_6_ENABLE 0
#endif
#ifndef CONF_USART_7_ENABLE
#define CONF_USART_7_ENABLE 0
#endif

/** Amount of USART. */
#define USART_AMOUNT                                                                                                   \
	(CONF_USART_0_ENABLE + CONF_USART_1_ENABLE + CONF_USART_2_ENABLE + CONF_USART_3_ENABLE + CONF_USART_4_ENABLE       \
	 + CONF_USART_5_ENABLE                                                                                             \
	 + CONF_USART_6_ENABLE                                                                                             \
	 + CONF_USART_7_ENABLE)

/**
 * \brief Macro is used to fill usart configuration structure based on
 * its number
 *
 * \param[in] n The number of structures
 */
#define USART_CONFIGURATION(n)                                                                                         \
	{                                                                                                                  \
		n, US_MR_USART_MODE(0x0) | US_MR_USCLKS(CONF_FLEXCOM##n##_CK_SRC) | US_MR_CHRL(CONF_USART_##n##_CHSIZE)        \
		       | (CONF_USART_##n##_MODE << US_MR_SYNC_Pos) | US_MR_PAR(CONF_USART_##n##_PARITY)                        \
		       | US_MR_NBSTOP(CONF_USART_##n##_SBMODE) | US_MR_CHMODE(CONF_USART_##n##_CHMODE)                         \
		       | (CONF_USART_##n##_MSBF << US_MR_MSBF_Pos) | (CONF_USART_##n##_MODE9 << US_MR_MODE9_Pos)               \
		       | (CONF_USART_##n##_CLKO << US_MR_CLKO_Pos) | (CONF_USART_##n##_OVER << US_MR_OVER_Pos)                 \
		       | (CONF_USART_##n##_INACK << US_MR_INACK_Pos) | (CONF_USART_##n##_DSNACK << US_MR_DSNACK_Pos)           \
		       | (CONF_USART_##n##_INVDATA << US_MR_INVDATA_Pos) | US_MR_MAX_ITERATION(CONF_USART_##n##_MAX_ITERATION) \
		       | (CONF_USART_##n##_FILTER << US_MR_FILTER_Pos),                                                        \
		    US_BRGR_CD(CONF_USART_##n##_BAUD_CD) | US_BRGR_FP(CONF_USART_##n##_BAUD_FP), (FLEXCOM##n)                  \
	}

/**
 * \brief USART configuration type
 */
struct usart_configuration {
	uint8_t                 number;
	hri_usart_us_mr_reg_t   us_mr;
	hri_usart_us_brgr_reg_t us_brgr;
	void *                  flexcom;
};

#if USART_AMOUNT < 1
/** Dummy array to pass compiling. */
static struct usart_configuration _usarts[1] = {{0}};
#else
/**
 * \brief Array of USART configurations
 */
static struct usart_configuration _usarts[] = {
#if CONF_USART_0_ENABLE == 1
    USART_CONFIGURATION(0),
#endif
#if CONF_USART_1_ENABLE == 1
    USART_CONFIGURATION(1),
#endif
#if CONF_USART_2_ENABLE == 1
    USART_CONFIGURATION(2),
#endif
#if CONF_USART_3_ENABLE == 1
    USART_CONFIGURATION(3),
#endif
#if CONF_USART_4_ENABLE == 1
    USART_CONFIGURATION(4),
#endif
#if CONF_USART_5_ENABLE == 1
    USART_CONFIGURATION(5),
#endif
#if CONF_USART_6_ENABLE == 1
    USART_CONFIGURATION(6),
#endif
#if CONF_USART_7_ENABLE == 1
    USART_CONFIGURATION(7),
#endif
};
#endif

/* The priority of the peripheral should be between the low and high interrupt priority set by chosen RTOS,
  * Otherwise, some of the RTOS APIs may fail to work inside interrupts
  * In case of FreeRTOS,the Lowest Interrupt priority is set by configLIBRARY_LOWEST_INTERRUPT_PRIORITY and
  * Maximum interrupt priority by configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY, So Interrupt Priority of the peripheral
 * should be between
  * configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY andconfigLIBRARY_LOWEST_INTERRUPT_PRIORITY */
#define USART_INTERRUPT_PRIORITY 6

static struct _usart_async_device *_usart0_dev = NULL;

static struct _usart_async_device *_usart1_dev = NULL;

static struct _usart_async_device *_usart6_dev = NULL;

static uint8_t _usart_get_irq_num(const void *const hw);
static uint8_t _get_usart_index(const void *const hw);
static uint8_t _usart_get_hardware_index(const void *const hw);

static int32_t _usart_init(void *const hw);
static inline void _usart_enable(void *const hw);
static inline void _usart_disable(void *const hw);
static inline void _usart_deinit(void *const hw);
static uint16_t _usart_calculate_baud_rate(const uint32_t baud, const uint32_t clock_rate, const uint8_t samples,
                                           const enum usart_baud_rate_mode mode, const uint8_t fraction);
static void _usart_set_baud_rate(void *const hw, const uint32_t baud_rate);
static void _usart_set_data_order(void *const hw, const enum usart_data_order order);
static void _usart_set_mode(void *const hw, const enum usart_mode mode);
static void _usart_set_parity(void *const hw, const enum usart_parity parity);
static void _usart_set_stop_bits(void *const hw, const enum usart_stop_bits stop_bits);
static void _usart_set_character_size(void *const hw, const enum usart_character_size size);

/**
 * \brief Retrieve IRQ number for the given hardware instance
 */
static uint8_t _usart_get_irq_num(const void *const hw)
{
	ASSERT(hw);

	if (hw == USART0) {
		return FLEXCOM0_IRQn;
	} else if (hw == USART1) {
		return FLEXCOM1_IRQn;
	} else if (hw == USART2) {
		return FLEXCOM2_IRQn;
	} else if (hw == USART3) {
		return FLEXCOM3_IRQn;
	} else if (hw == USART4) {
		return FLEXCOM4_IRQn;
	} else if (hw == USART5) {
		return FLEXCOM5_IRQn;
	} else if (hw == USART6) {
		return FLEXCOM6_IRQn;
	} else if (hw == USART7) {
		return FLEXCOM7_IRQn;
	}

	ASSERT(false);
	return 0;
}

/**
 * \brief Init irq param with the given usart hardware instance
 */
static void _usart_init_irq_param(const void *const hw, struct _usart_async_device *dev)
{
	uint8_t test = 1;
	uint8_t test2 = 5;
	uint8_t result = 0;
	if (hw == USART0) {
		_usart0_dev = dev;
	}
	if (hw == USART1) {
		_usart1_dev = dev;
	}
	if (hw == USART6) {
		_usart6_dev = dev;
	}
	result = test + test2;
}

/**
 * \brief Initialize synchronous USART
 */
int32_t _usart_sync_init(struct _usart_sync_device *const device, void *const hw)
{
	ASSERT(device);
	ASSERT(hw);

	device->hw = (void *)((uint32_t)hw + 0x200U);

	return _usart_init(device->hw);
}

/**
 * \brief Initialize asynchronous USART
 */
int32_t _usart_async_init(struct _usart_async_device *const device, void *const hw)
{
	int32_t init_status;

	ASSERT(device);

	//device->hw = (void *)((uint32_t)hw + 0x200U);
	device->hw = (void *)((uint32_t)hw);

	init_status = _usart_init(device->hw);
	if (init_status) {
		return init_status;
	}

	_usart_init_irq_param(hw, device);
	NVIC_DisableIRQ((IRQn_Type)_usart_get_irq_num(device->hw));
	NVIC_ClearPendingIRQ((IRQn_Type)_usart_get_irq_num(device->hw));
	NVIC_EnableIRQ((IRQn_Type)_usart_get_irq_num(device->hw));

	return ERR_NONE;
}

/**
 * \brief De-initialize USART
 */
void _usart_sync_deinit(struct _usart_sync_device *const device)
{
	ASSERT(device);
	_usart_deinit(device->hw);
}

/**
 * \brief De-initialize USART
 */
void _usart_async_deinit(struct _usart_async_device *const device)
{
	ASSERT(device);
	NVIC_DisableIRQ((IRQn_Type)_usart_get_irq_num(device->hw));
	_usart_deinit(device->hw);
}

/**
 * \brief Calculate baud rate register value
 */
uint16_t _usart_sync_calculate_baud_rate(const uint32_t baud, const uint32_t clock_rate, const uint8_t samples,
                                         const enum usart_baud_rate_mode mode, const uint8_t fraction)
{
	return _usart_calculate_baud_rate(baud, clock_rate, samples, mode, fraction);
}

/**
 * \brief Calculate baud rate register value
 */
uint16_t _usart_async_calculate_baud_rate(const uint32_t baud, const uint32_t clock_rate, const uint8_t samples,
                                          const enum usart_baud_rate_mode mode, const uint8_t fraction)
{
	return _usart_calculate_baud_rate(baud, clock_rate, samples, mode, fraction);
}

/**
 * \brief Enable USART sync module
 */
void _usart_sync_enable(struct _usart_sync_device *const device)
{
	ASSERT(device);
	_usart_enable(device->hw);
}

/**
 * \brief Enable USART async module
 */
void _usart_async_enable(struct _usart_async_device *const device)
{
	ASSERT(device);
	_usart_enable(device->hw);
}

/**
 * \brief Disable USART sync module
 */
void _usart_sync_disable(struct _usart_sync_device *const device)
{
	ASSERT(device);
	_usart_disable(device->hw);
}

/**
 * \brief Disable USART async module
 */
void _usart_async_disable(struct _usart_async_device *const device)
{
	ASSERT(device);
	_usart_disable(device->hw);
}

/**
 * \brief Set baud rate
 */
void _usart_sync_set_baud_rate(struct _usart_sync_device *const device, const uint32_t baud_rate)
{
	ASSERT(device);
	_usart_set_baud_rate(device->hw, baud_rate);
}

/**
 * \brief Set baud rate
 */
void _usart_async_set_baud_rate(struct _usart_async_device *const device, const uint32_t baud_rate)
{
	ASSERT(device);
	_usart_set_baud_rate(device->hw, baud_rate);
}

/**
 * \brief Set data order
 */
void _usart_sync_set_data_order(struct _usart_sync_device *const device, const enum usart_data_order order)
{
	ASSERT(device);
	_usart_set_data_order(device->hw, order);
}

/**
 * \brief Set data order
 */
void _usart_async_set_data_order(struct _usart_async_device *const device, const enum usart_data_order order)
{
	ASSERT(device);
	_usart_set_data_order(device->hw, order);
}

/**
 * \brief Set mode
 */
void _usart_sync_set_mode(struct _usart_sync_device *const device, const enum usart_mode mode)
{
	ASSERT(device);
	_usart_set_mode(device->hw, mode);
}

/**
 * \brief Set mode
 */
void _usart_async_set_mode(struct _usart_async_device *const device, const enum usart_mode mode)
{
	ASSERT(device);
	_usart_set_mode(device->hw, mode);
}

/**
 * \brief Set parity
 */
void _usart_sync_set_parity(struct _usart_sync_device *const device, const enum usart_parity parity)
{
	ASSERT(device);
	_usart_set_parity(device->hw, parity);
}

/**
 * \brief Set parity
 */
void _usart_async_set_parity(struct _usart_async_device *const device, const enum usart_parity parity)
{
	ASSERT(device);
	_usart_set_parity(device->hw, parity);
}

/**
 * \brief Set stop bits mode
 */
void _usart_sync_set_stop_bits(struct _usart_sync_device *const device, const enum usart_stop_bits stop_bits)
{
	ASSERT(device);
	_usart_set_stop_bits(device->hw, stop_bits);
}

/**
 * \brief Set stop bits mode
 */
void _usart_async_set_stop_bits(struct _usart_async_device *const device, const enum usart_stop_bits stop_bits)
{
	ASSERT(device);
	_usart_set_stop_bits(device->hw, stop_bits);
}

/**
 * \brief Set character size
 */
void _usart_sync_set_character_size(struct _usart_sync_device *const device, const enum usart_character_size size)
{
	ASSERT(device);
	_usart_set_character_size(device->hw, size);
}

/**
 * \brief Set character size
 */
void _usart_async_set_character_size(struct _usart_async_device *const device, const enum usart_character_size size)
{
	ASSERT(device);
	_usart_set_character_size(device->hw, size);
}

/**
 * \brief Retrieve usart status
 */
uint32_t _usart_sync_get_status(const struct _usart_sync_device *const device)
{
	ASSERT(device);
	return (uint32_t)hri_usart_read_US_CSR_reg(device->hw);
}

/**
 * \brief Retrieve usart status
 */
uint32_t _usart_async_get_status(const struct _usart_async_device *const device)
{
	ASSERT(device);
	return (uint32_t)hri_usart_read_US_CSR_reg(device->hw);
}

/**
 * \brief Write a byte to the given USART instance
 */
void _usart_sync_write_byte(struct _usart_sync_device *const device, uint8_t data)
{
	ASSERT(device);
	hri_usart_write_US_THR_reg(device->hw, (hri_usart_us_thr_reg_t)data);
}

/**
 * \brief Write a byte to the given USART instance
 */
void _usart_async_write_byte(struct _usart_async_device *const device, uint8_t data)
{
	ASSERT(device);
	hri_usart_write_US_THR_reg(device->hw, (hri_usart_us_thr_reg_t)data);
}

/**
 * \brief Read a byte from the given USART instance
 */
uint8_t _usart_sync_read_byte(const struct _usart_sync_device *const device)
{
	ASSERT(device);
	return (uint8_t)(hri_usart_read_US_RHR_reg(device->hw) & 0xff);
}

/**
 * \brief Check if USART is ready to send next byte
 */
bool _usart_sync_is_byte_sent(const struct _usart_sync_device *const device)
{
	ASSERT(device);
	return hri_usart_get_US_CSR_TXRDY_bit(device->hw);
}

/**
 * \brief Check if USART is ready to send next byte
 */
bool _usart_async_is_byte_sent(const struct _usart_async_device *const device)
{
	ASSERT(device);
	return hri_usart_get_US_CSR_TXRDY_bit(device->hw);
}

/**
 * \brief Check if there is data received by USART
 */
bool _usart_sync_is_byte_received(const struct _usart_sync_device *const device)
{
	ASSERT(device);
	return hri_usart_get_US_CSR_RXRDY_bit(device->hw);
}

/**
 * \brief Set the state of flow control pins
 */
void _usart_sync_set_flow_control_state(struct _usart_sync_device *const     device,
                                        const union usart_flow_control_state state)
{
	ASSERT(device);
	(void)device;
	(void)state;
}

/**
 * \brief Set the state of flow control pins
 */
void _usart_async_set_flow_control_state(struct _usart_async_device *const    device,
                                         const union usart_flow_control_state state)
{
	ASSERT(device);
	(void)device;
	(void)state;
}

/**
 * \brief Retrieve the state of flow control pins
 */
union usart_flow_control_state _usart_sync_get_flow_control_state(const struct _usart_sync_device *const device)
{
	ASSERT(device);
	(void)device;
	union usart_flow_control_state state;

	state.value           = 0;
	state.bit.unavailable = 1;
	return state;
}

/**
 * \brief Retrieve the state of flow control pins
 */
union usart_flow_control_state _usart_async_get_flow_control_state(const struct _usart_async_device *const device)
{
	ASSERT(device);
	(void)device;
	union usart_flow_control_state state;

	state.value           = 0;
	state.bit.unavailable = 1;
	return state;
}

/**
 * \brief Enable data register empty interrupt
 */
void _usart_async_enable_byte_sent_irq(struct _usart_async_device *const device)
{
	ASSERT(device);
	hri_usart_set_US_IMR_TXRDY_bit(device->hw);
}

/**
 * \brief Enable transmission complete interrupt
 */
void _usart_async_enable_tx_done_irq(struct _usart_async_device *const device)
{
	ASSERT(device);
	hri_usart_set_US_IMR_TXEMPTY_bit(device->hw);
}

/**
 * \brief Retrieve ordinal number of the given usart hardware instance
 */
static uint8_t _usart_get_hardware_index(const void *const hw)
{
	ASSERT(hw);

#ifdef _UNIT_TEST_
	return ((uint32_t)hw - (uint32_t)USART0) / sizeof(Usart);
#endif
	if (hw == USART0) {
		return 0;
	} else if (hw == USART1) {
		return 1;
	} else if (hw == USART2) {
		return 2;
	} else if (hw == USART3) {
		return 3;
	} else if (hw == USART4) {
		return 4;
	} else if (hw == USART5) {
		return 5;
	} else if (hw == USART6) {
		return 6;
	} else if (hw == USART7) {
		return 7;
	}

	ASSERT(false);
	return 0;
}

/**
 * \brief Retrieve ordinal number of the given USART hardware instance
 */
uint8_t _usart_sync_get_hardware_index(const struct _usart_sync_device *const device)
{
	ASSERT(device);
	return _usart_get_hardware_index(device->hw);
}

/**
 * \brief Retrieve ordinal number of the given USART hardware instance
 */
uint8_t _usart_async_get_hardware_index(const struct _usart_async_device *const device)
{
	ASSERT(device);
	return _usart_get_hardware_index(device->hw);
}

/**
 * \brief Enable/disable USART interrupt
 */
void _usart_async_set_irq_state(struct _usart_async_device *const device, const enum _usart_async_callback_type type,
                                const bool state)
{
	ASSERT(device);
	if (state) {
		if (USART_ASYNC_BYTE_SENT == type || USART_ASYNC_TX_DONE == type) {
			hri_usart_set_US_IMR_TXRDY_bit(device->hw);
			hri_usart_set_US_IMR_TXEMPTY_bit(device->hw);
		} else if (USART_ASYNC_RX_DONE == type) {
			hri_usart_set_US_IMR_RXRDY_bit(device->hw);
		} else if (USART_ASYNC_ERROR == type) {
			hri_usart_set_US_IMR_reg(device->hw, US_CSR_OVRE | US_CSR_FRAME | US_CSR_PARE);
		}
	} else {
		if (USART_ASYNC_BYTE_SENT == type || USART_ASYNC_TX_DONE == type) {
			hri_usart_clear_US_IMR_TXRDY_bit(device->hw);
			hri_usart_clear_US_IMR_TXEMPTY_bit(device->hw);
		} else if (USART_ASYNC_RX_DONE == type) {
			hri_usart_clear_US_IMR_RXRDY_bit(device->hw);
		} else if (USART_ASYNC_ERROR == type) {
			hri_usart_clear_US_IMR_reg(device->hw, US_CSR_OVRE | US_CSR_FRAME | US_CSR_PARE);
		}
	}
}

/**
 * \brief Retrieve usart sync helper functions
 */
void *_usart_get_usart_sync(void)
{
	return (void *)NULL;
}

/**
 * \brief Retrieve usart async helper functions
 */
void *_usart_get_usart_async(void)
{
	return (void *)NULL;
}

/**
 * \internal Usart interrupt handler
 *
 * \param[in] p The pointer to interrupt parameter
 */
static void _usart_interrupt_handler(struct _usart_async_device *device)
{
	ASSERT(device);
	void *hw = device->hw;

	if (hri_usart_get_US_CSR_TXRDY_bit(hw) && hri_usart_get_US_IMR_TXRDY_bit(hw)) {
		hri_usart_clear_US_IMR_TXRDY_bit(hw);
		device->usart_cb.tx_byte_sent(device);
	} else if (hri_usart_get_US_CSR_TXEMPTY_bit(hw) && hri_usart_get_US_IMR_TXEMPTY_bit(hw)) {
		hri_usart_clear_US_IMR_TXEMPTY_bit(hw);
		device->usart_cb.tx_done_cb(device);
	} else if (hri_usart_get_US_CSR_RXRDY_bit(hw) && hri_usart_get_US_IMR_RXRDY_bit(hw)) {
		if (hri_usart_read_US_CSR_reg(hw) & (US_CSR_OVRE | US_CSR_FRAME | US_CSR_PARE)) {
			hri_usart_read_US_RHR_reg(hw);
			hri_usart_write_US_CR_reg(hw, US_CR_RSTSTA);
			return;
		}

		device->usart_cb.rx_done_cb(device, (uint8_t)hri_usart_read_US_RHR_reg(hw));
	} else if (hri_usart_read_US_CSR_reg(hw) & (US_CSR_OVRE | US_CSR_FRAME | US_CSR_PARE)) {
		hri_usart_write_US_CR_reg(hw, US_CR_RSTSTA);
		device->usart_cb.error_cb(device);
	}
}

/**
 * \internal USART interrupt handler
 */
void FLEXCOM0_Handler(void)
{
	_usart_interrupt_handler(_usart0_dev);
}

/**
 * \internal USART interrupt handler
 */
void FLEXCOM1_Handler(void)
{
	_usart_interrupt_handler(_usart1_dev);
}

/**
 * \internal USART interrupt handler
 */
void FLEXCOM6_Handler(void)
{
	_usart_interrupt_handler(_usart6_dev);
}

/**
 * \internal Retrieve ordinal number of the given usart hardware instance
 *
 * \param[in] hw The pointer to hardware instance

 * \return The ordinal number of the given usart hardware instance
 */
static uint8_t _get_usart_index(const void *const hw)
{
	ASSERT(hw);
	uint8_t usart_offset = _usart_get_hardware_index(hw);
	uint8_t i;

	for (i = 0; i < ARRAY_SIZE(_usarts); i++) {
		if (_usarts[i].number == usart_offset) {
			return i;
		}
	}

	ASSERT(false);
	return 0;
}

/**
 * \internal Initialize USART
 *
 * \param[in] hw The pointer to hardware instance
 *
 * \return The status of initialization
 */
static int32_t _usart_init(void *const hw)
{
	ASSERT(hw);
	uint8_t i = _get_usart_index(hw);

	hri_flexcom_write_MR_reg(_usarts[i].flexcom, FLEXCOM_MR_OPMODE_USART);

	/* Disable the Write Protect. */
	hri_usart_write_US_WPMR_reg(hw, US_WPMR_WPKEY_PASSWD);

	/* Reset registers that could cause unpredictable behavior after reset. */
	hri_usart_write_US_MR_reg(hw, 0x0);
	hri_usart_write_US_RTOR_reg(hw, 0x0);
	hri_usart_write_US_TTGR_reg(hw, 0x0);

	/* Disable and reset TX and RX. */
	hri_usart_write_US_CR_reg(hw, US_CR_RSTRX | US_CR_RXDIS | US_CR_RSTTX | US_CR_TXDIS);
	/* Reset status bits. */
	hri_usart_write_US_CR_reg(hw, US_CR_RSTSTA);
	/* Turn off RTS and DTR if exist. */
	hri_usart_write_US_CR_reg(hw, US_CR_RTSDIS);

	hri_usart_write_US_MR_reg(hw, _usarts[i].us_mr);
	hri_usart_write_US_BRGR_reg(hw, _usarts[i].us_brgr);

	return ERR_NONE;
}

/**
 * \internal De-initialize USART
 *
 * \param[in] hw The pointer to hardware instance
 */
static inline void _usart_deinit(void *const hw)
{
	ASSERT(hw);
	hri_usart_write_US_CR_reg(hw, US_CR_RSTRX | US_CR_RSTTX | US_CR_RSTSTA);
}

/**
 * \internal Enable USART
 *
 * \param[in] hw The pointer to hardware instance
 */
static inline void _usart_enable(void *const hw)
{
	ASSERT(hw);
	hri_usart_write_US_CR_reg(hw, US_CR_RXEN | US_CR_TXEN);
}

/**
 * \internal Disable USART
 *
 * \param[in] hw The pointer to hardware instance
 */
static inline void _usart_disable(void *const hw)
{
	ASSERT(hw);
	hri_usart_write_US_CR_reg(hw, US_CR_RXDIS | US_CR_TXDIS);
}

/**
 * \internal Calculate baud rate register value
 *
 * \param[in] baud Required baud rate
 * \param[in] clock_rate USART clock frequency
 * \param[in] samples The number of samples
 * \param[in] mode USART mode
 * \param[in] fraction A fraction value
 *
 * \return Calculated baud rate register value
 */
static uint16_t _usart_calculate_baud_rate(const uint32_t baud, const uint32_t clock_rate, const uint8_t samples,
                                           const enum usart_baud_rate_mode mode, const uint8_t fraction)
{
	if (USART_BAUDRATE_ASYNCH_ARITHMETIC == mode) {
		return clock_rate / baud / samples;
	}

	if (USART_BAUDRATE_ASYNCH_FRACTIONAL == mode) {
		return clock_rate / baud / samples + US_BRGR_FP(fraction);
	}

	if (USART_BAUDRATE_SYNCH == mode) {
		return clock_rate / baud;
	}

	return 0;
}

/**
 * \internal Set baud rate
 *
 * \param[in] device The pointer to USART device instance
 * \param[in] baud_rate A baud rate to set
 */
static void _usart_set_baud_rate(void *const hw, const uint32_t baud_rate)
{
	ASSERT(hw);
	uint32_t usart_freq, cd = 0, fp = 0, clock_select;
	bool     over;
	uint8_t  i = _get_usart_index(hw);
	switch (i) {
	case 0:
#ifdef CONF_FLEXCOM0_FREQUENCY
		usart_freq = CONF_FLEXCOM0_FREQUENCY;
#endif
		break;

	case 1:
#ifdef CONF_FLEXCOM1_FREQUENCY
		usart_freq = CONF_FLEXCOM1_FREQUENCY;
#endif
		break;

	case 2:
#ifdef CONF_FLEXCOM2_FREQUENCY
		usart_freq = CONF_FLEXCOM2_FREQUENCY;
#endif
		break;
	case 3:
#ifdef CONF_FLEXCOM3_FREQUENCY
		usart_freq = CONF_FLEXCOM3_FREQUENCY;
#endif
		break;
	case 4:
#ifdef CONF_FLEXCOM4_FREQUENCY
		usart_freq = CONF_FLEXCOM4_FREQUENCY;
#endif
		break;
	case 5:
#ifdef CONF_FLEXCOM5_FREQUENCY
		usart_freq = CONF_FLEXCOM5_FREQUENCY;
#endif
		break;
	case 6:
#ifdef CONF_FLEXCOM6_FREQUENCY
		usart_freq = CONF_FLEXCOM6_FREQUENCY;
#endif
		break;

	case 7:
#ifdef CONF_FLEXCOM7_FREQUENCY
		usart_freq = CONF_FLEXCOM7_FREQUENCY;
#endif
		break;

	default:
		ASSERT(false);
	}

	clock_select = hri_usart_read_US_MR_USCLKS_bf(hw);
	if (hri_usart_get_US_MR_SYNC_bit(hw)) {
		switch (clock_select) {
		case 0x0:
		case 0x1:
		case 0x2:
			cd = usart_freq / baud_rate;
			fp = usart_freq * 8 / baud_rate - 8 * cd;
			break;

		case 0x3:
			break;

		default:
			ASSERT(false);
		}
	} else {
		over = hri_usart_get_US_MR_OVER_bit(hw);
		switch (clock_select) {
		case 0x0:
		case 0x1:
		case 0x2:
			cd = usart_freq / baud_rate / 8 / (2 - over);
			fp = usart_freq / baud_rate / (2 - over) - 8 * cd;
			break;

		case 0x3:
			break;

		default:
			ASSERT(false);
		}
	}
	hri_usart_write_US_WPMR_reg(hw, US_WPMR_WPKEY_PASSWD);
	hri_usart_write_US_BRGR_reg(hw, US_BRGR_CD(cd) | US_BRGR_FP(fp));
}

/**
 * \internal Set data order
 *
 * \param[in] device The pointer to USART device instance
 * \param[in] order A data order to set
 */
static void _usart_set_data_order(void *const hw, const enum usart_data_order order)
{
	ASSERT(hw);
	hri_usart_write_US_WPMR_reg(hw, US_WPMR_WPKEY_PASSWD);
	if (order == USART_DATA_ORDER_MSB) {
		hri_usart_set_US_MR_MSBF_bit(hw);
	} else {
		hri_usart_clear_US_MR_MSBF_bit(hw);
	}
}

/**
 * \internal Set mode
 *
 * \param[in] device The pointer to USART device instance
 * \param[in] mode A mode to set
 */
static void _usart_set_mode(void *const hw, const enum usart_mode mode)
{
	ASSERT(hw);
	hri_usart_write_US_WPMR_reg(hw, US_WPMR_WPKEY_PASSWD);
	if (mode == USART_MODE_SYNCHRONOUS) {
		hri_usart_set_US_MR_SYNC_bit(hw);
	} else {
		hri_usart_clear_US_MR_SYNC_bit(hw);
	}
}

/**
 * \internal Set parity
 *
 * \param[in] device The pointer to USART device instance
 * \param[in] parity A parity to set
 */
static void _usart_set_parity(void *const hw, const enum usart_parity parity)
{
	ASSERT(hw);
	hri_usart_write_US_WPMR_reg(hw, US_WPMR_WPKEY_PASSWD);
	switch (parity) {
	case USART_PARITY_EVEN:
		hri_usart_write_US_MR_PAR_bf(hw, (hri_usart_us_mr_reg_t)0x0u);
		break;

	case USART_PARITY_ODD:
		hri_usart_write_US_MR_PAR_bf(hw, (hri_usart_us_mr_reg_t)0x1u);
		break;

	case USART_PARITY_SPACE:
		hri_usart_write_US_MR_PAR_bf(hw, (hri_usart_us_mr_reg_t)0x2u);
		break;

	case USART_PARITY_MARK:
		hri_usart_write_US_MR_PAR_bf(hw, (hri_usart_us_mr_reg_t)0x3u);
		break;

	case USART_PARITY_NONE:
		hri_usart_write_US_MR_PAR_bf(hw, (hri_usart_us_mr_reg_t)0x4u);
		break;

	default:
		ASSERT(false);
	}
}

/**
 * \internal Set stop bits mode
 *
 * \param[in] device The pointer to USART device instance
 * \param[in] stop_bits A stop bits mode to set
 */
static void _usart_set_stop_bits(void *const hw, const enum usart_stop_bits stop_bits)
{
	ASSERT(hw);
	hri_usart_write_US_WPMR_reg(hw, US_WPMR_WPKEY_PASSWD);
	switch (stop_bits) {
	case USART_STOP_BITS_ONE:
		hri_usart_write_US_MR_NBSTOP_bf(hw, (hri_usart_us_mr_reg_t)0x0u);
		break;

	case USART_STOP_BITS_TWO:
		hri_usart_write_US_MR_NBSTOP_bf(hw, (hri_usart_us_mr_reg_t)0x2u);
		break;

	case USART_STOP_BITS_ONE_P_FIVE:
		hri_usart_write_US_MR_NBSTOP_bf(hw, (hri_usart_us_mr_reg_t)0x1u);
		break;

	default:
		ASSERT(false);
	}
}

/**
 * \internal Set character size
 *
 * \param[in] device The pointer to USART device instance
 * \param[in] size A character size to set
 */
static void _usart_set_character_size(void *const hw, const enum usart_character_size size)
{
	ASSERT(hw);
	hri_usart_write_US_WPMR_reg(hw, US_WPMR_WPKEY_PASSWD);
	if (size == USART_CHARACTER_SIZE_9BITS) {
		hri_usart_set_US_MR_MODE9_bit(hw);
	} else {
		hri_usart_clear_US_MR_MODE9_bit(hw);
		switch (size) {
		case USART_CHARACTER_SIZE_5BITS:
			hri_usart_write_US_MR_CHRL_bf(hw, (hri_usart_us_mr_reg_t)0x0u);
			break;

		case USART_CHARACTER_SIZE_6BITS:
			hri_usart_write_US_MR_CHRL_bf(hw, (hri_usart_us_mr_reg_t)0x1u);
			break;

		case USART_CHARACTER_SIZE_7BITS:
			hri_usart_write_US_MR_CHRL_bf(hw, (hri_usart_us_mr_reg_t)0x2u);
			break;

		case USART_CHARACTER_SIZE_8BITS:
			hri_usart_write_US_MR_CHRL_bf(hw, (hri_usart_us_mr_reg_t)0x3u);
			break;

		default:
			ASSERT(false);
		}
	}
}
